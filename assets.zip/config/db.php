<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=yamy',
    'username' => 'root',
    'password' => 'abc@123',
    'charset' => 'utf8',
];
